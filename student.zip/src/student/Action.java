package student;

import java.util.Scanner;

public interface Action {
	public void execute(Scanner sc);	
}
